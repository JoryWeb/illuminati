<?php

require_once(dirname(__FILE__) . '/simpletest/autorun.php');